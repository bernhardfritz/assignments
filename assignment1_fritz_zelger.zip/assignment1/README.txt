Instructions
============
open terminal and type:
make
./MerryGoRound

Compiled and executed in RR15
